;; ============================================================================
;; ORGMODE CONFIGURATION
;; ============================================================================
;; Reorganized 2026-08-01 for the domain-based @embrace_entropy layout.
;; No external packages required — all built-in org features.

;; ----------------------------------------------------------------------------
;; File paths
;; ----------------------------------------------------------------------------
(setq org-directory "~/sbemode/@embrace_entropy/")

;; Agenda scans EVERY .org file under the repo, at any depth, so the
;; top-level content folders (people/ notes/ growth/ ...) are picked up
;; automatically.
(setq org-agenda-files
      (directory-files-recursively "~/sbemode/@embrace_entropy/" "\\.org$"))

;; Archive now lives under archive/. Kept as .log so it stays OUT of the agenda.
(setq org-archive-location
      "~/sbemode/@embrace_entropy/zzzarchive/org-archive.log::")

;; Quick-capture inbox + refile anywhere in the agenda files.
(setq org-default-notes-file "~/sbemode/@embrace_entropy/inbox.org")
(setq org-refile-targets '((org-agenda-files :maxlevel . 3)))
(setq org-refile-use-outline-path 'file)
(setq org-outline-path-complete-in-steps nil)

;; Fold state/completion logs into a :LOGBOOK: drawer from now on (tidier).
(setq org-log-into-drawer t)

;; ----------------------------------------------------------------------------
;; TODO keywords + faces
;;   Redesigned 2026-08-04 to separate status (this sequence) from structure
;;   (the :project: tag) and from domain/person (tags). See
;;   zzzDesignProposal.md for the full rationale.
;; ----------------------------------------------------------------------------
(setq org-todo-keywords
      '((sequence "TODO(t)"
		  "WAITING(w)"
		  "PROJECT(p)"
		  "AGENDA(a)"
		  "FUTURE(f)"
		  "GOAL(g)"
		  "|"
		  "DONE(d)"
		  "CANCEL(x)")))

;; Colors pinned to hex (not terminal-relative names like "brightred") so
;; they render identically in Ghostty and Emacs.app -- values taken straight
;; from Ghostty's "Bright Lights" theme palette.
(setq org-todo-keyword-faces
      '(("TODO" . (:foreground "#ffffff" :background "#ff1a1a"))
	("WAITING" . (:foreground "#c9c9c9" :background "#7a2430"))
	("PROJECT" . (:foreground "#191919" :background "#ff6600"))
	("AGENDA" . (:foreground "#ba76e7" :background "#4c4c4c"))
	("GOAL" . (:foreground "#191919" :background "#ba76e7"))
	("FUTURE" . (:foreground "#ffffff" :background "#3e8fc0"))
    ("DONE" . (:foreground "#191919" :background "#4c4c4c"))
    ("CANCEL" . (:foreground "#4c4c4c" :background "#191919"))))

;; ----------------------------------------------------------------------------
;; Tags — all lowercase.  People are prefixed with @.
;; ----------------------------------------------------------------------------
(setq org-tag-alist
    '(("@me" . ?m)
	("@boss" . ?v)         ; role-based; whoever's above me right now
	("@scott" . ?s)
	("@becca" . ?b)
	("@courtney" . ?u)
	("@don" . ?d)
	("@matt" . ?a)
	("work" . ?w)
	("home" . ?h)
	("team" . ?t)          ; "bring to the team meeting"
	("project" . ?j)))     ; container heading with TODO/HANDOFF children

;; ----------------------------------------------------------------------------
;; Agenda dispatcher + custom views
;;   C-c a          -> dispatcher
;;   a              -> normal day/week agenda (what `sb` opens)
;;   1 / 2 / 3      -> boss / team / projects
;;   4 / 5          -> work / home
;;   p then s/b/c/d/m -> per-person open items
;; ----------------------------------------------------------------------------
(global-set-key (kbd "C-c a") 'org-agenda)
(setq org-agenda-custom-commands
      '(("1" "Boss 1:1"      tags-todo "@boss")
        ("2" "Team meeting"  tags-todo "team")
        ("3" "Projects"      tags-todo "project")
        ("4" "Work"          tags-todo "work")
        ("5" "Home"          tags-todo "home")
        ("p" . "Per-person open items")
        ("ps" "Scott"    tags-todo "@scott")
        ("pb" "Becca"    tags-todo "@becca")
        ("pc" "Courtney" tags-todo "@courtney")
        ("pd" "Don"      tags-todo "@don")
        ("pm" "Matt"     tags-todo "@matt")))

;; ----------------------------------------------------------------------------
;; Capture  (C-c c)
;; ----------------------------------------------------------------------------
(global-set-key (kbd "C-c c") 'org-capture)
(setq org-capture-templates
      '(("t" "Todo -> inbox" entry
         (file+headline org-default-notes-file "Inbox")
         "* TODO %? %<%Y-%m-%d@%H:%M>")
        ("n" "Note -> inbox" entry
         (file+headline org-default-notes-file "Inbox")
         "* %? %<%Y-%m-%d@%H:%M>")
        ("m" "Meeting note -> new dated file in notes/" plain
         (file (lambda ()
                 (expand-file-name
                  (concat (format-time-string "%Y%b%d") ".org")
                  "~/sbemode/@embrace_entropy/notes/")))
         "#+TITLE: %^{Meeting title}\n%U\n\n%?")))

;; ----------------------------------------------------------------------------
;; Deft — now searches the whole repo (notes live across many folders)
;; ----------------------------------------------------------------------------
(setq deft-extensions '("txt" "org" "md"))
(setq deft-directory "~/sbemode/@embrace_entropy")
(setq deft-recursive t)
(setq deft-default-extension "org")
(setq deft-new-file-format "%Y%b%d")

;; ----------------------------------------------------------------------------
;; On-demand log cleanup — "zero out" completion drawers  (C-c z)
;; ----------------------------------------------------------------------------
(defun bsd/clear-logbooks ()
  "Delete all :LOGBOOK: drawers in the current buffer.
Completion logs fold into :LOGBOOK: drawers; run this in recurring.org
whenever they pile up to wipe them in one keystroke.  Leaves :PROPERTIES:
drawers (and LAST_REPEAT) untouched, so recurrences keep working."
  (interactive)
  (let ((n 0))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward
              "^[ \t]*:LOGBOOK:[ \t]*\n\\(?:.*\n\\)*?[ \t]*:END:[ \t]*\n?" nil t)
        (replace-match "")
        (setq n (1+ n))))
    (message "Cleared %d LOGBOOK drawer%s." n (if (= n 1) "" "s"))))

(global-set-key (kbd "C-c z") 'bsd/clear-logbooks)

(provide 'orgmode)
