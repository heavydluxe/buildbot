((magit-commit
  ("--verbose")
  ("--verbose" "--all"))
 (magit-dispatch nil)
 (magit-push nil)
 (magit-tag nil))
