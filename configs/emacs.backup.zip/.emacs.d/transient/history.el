((magit-commit
  ("--verbose")
  ("--verbose" "--all"))
 (magit-push nil)
 (magit-tag nil))
