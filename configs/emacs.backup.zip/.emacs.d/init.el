;; ============================================================================
;; EMACS INIT - MAIN ENTRY POINT
;; ============================================================================
;; Author: @embrace_entropy
;; Purpose: Modular Emacs configuration starting with fundamentals

;; ============================================================================
;; PACKAGE MANAGEMENT
;; ============================================================================
(require 'package)
(add-to-list 'package-archives '("melpa-stable" . "https://stable.melpa.org/packages/"))
(package-initialize)

;; ============================================================================
;; EMACS-APP-FIRST WORKFLOW SUPPORT
;; ============================================================================

;; exec-path-from-shell: GUI Emacs.app (launched from Finder/Dock/Spotlight)
;; does not inherit PATH from ~/.zshrc the way `emacs` run inside a Ghostty
;; shell does. Pull it in so Emacs's own subprocess calls (magit, compile,
;; flycheck, etc.) can find binaries under /opt/homebrew, ~/.local/bin, etc.
;; The -initialize call is a no-op when window-system is nil (terminal
;; Emacs), so this is safe to keep even when working back in Ghostty.
(unless (package-installed-p 'exec-path-from-shell)
  (package-refresh-contents)
  (package-install 'exec-path-from-shell))

(when (memq window-system '(mac ns))
  (exec-path-from-shell-initialize))

;; ghostel: libghostty-vt-backed terminal emulator buffer (M-x ghostel)
(unless (package-installed-p 'ghostel)
  (package-refresh-contents)
  (package-install 'ghostel))

(unless (package-installed-p 'magit)
  (package-refresh-contents)
  (package-install 'magit))

;; GUI look & feel -- match Ghostty's "Bright Lights" theme (colors read
;; straight from the theme file at
;; /Applications/Ghostty.app/Contents/Resources/ghostty/themes/Bright Lights)
;; and font/size from Ghostty's own config, then drop the GUI chrome Ghostty
;; never had. Only applies to Emacs.app -- terminal Emacs already looks like
;; this for free since Ghostty is doing the rendering.
(when (memq window-system '(mac ns))
  (add-to-list 'default-frame-alist '(font . "JetBrainsMono Nerd Font-24"))
  (add-to-list 'default-frame-alist '(background-color . "#191919"))
  (add-to-list 'default-frame-alist '(foreground-color . "#b3c9d7"))
  (add-to-list 'default-frame-alist '(cursor-color . "#f34b00"))
  (add-to-list 'default-frame-alist '(fullscreen . fullboth))

  (set-face-attribute 'region nil :background "#b3c9d7" :foreground "#191919")

  (tool-bar-mode -1)
  (scroll-bar-mode -1))

;; ============================================================================
;; BASIC EMACS BEHAVIOR
;; ============================================================================

;; Visual line mode (wrap long lines)
(global-visual-line-mode 1)

;; Hide menu bar for more screen real estate
(menu-bar-mode -1)

;; IDO mode for file/buffer completion
(ido-mode 1)
(ido-everywhere 1)

;; which-key: show prefix options after a short pause
(which-key-mode 1)

;; Backup files location
(setq backup-directory-alist '(("." . "~/zzzemacs-backups")))

;; ============================================================================
;; CUSTOM KEYBINDINGS
;; ============================================================================
(global-set-key (kbd "C-c t") 'org-sparse-tree)

;; ============================================================================
;; ORGMODE CONFIGURATION
;; ============================================================================
(load-file "~/.emacs.d/lisp/orgmode.el")

;; ============================================================================
;; GUI STARTUP VIEW
;; ============================================================================

;; Land on the day agenda instead of the "*GNU Emacs*" welcome buffer,
;; mirroring what the `sb` alias in ~/.zshrc does for a terminal launch.
;; GUI-only: a plain `emacs` in Ghostty is unaffected, and `sb` still works
;; exactly as it does today.
(when (memq window-system '(mac ns))
  (setq inhibit-startup-screen t)
  (add-hook 'emacs-startup-hook
            (lambda ()
              (org-agenda nil "a")
              (org-agenda-day-view)
              (delete-other-windows))))

;; ============================================================================
;; FACES (cosmetic customizations)
;; ============================================================================
(custom-set-variables
 '(package-selected-packages nil))

(setq org-agenda-files
      (directory-files-recursively "~/@embrace_entropy" "\\.org$" nil
                                    (lambda (dir) (not (string-match-p "/\\." dir)))))
(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 )

(provide 'init)
