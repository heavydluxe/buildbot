;; ============================================================================
;; EMACS INIT - MAIN ENTRY POINT
;; ============================================================================
;; Author: @embrace_entropy
;; Purpose: Modular Emacs configuration starting with fundamentals

;; ============================================================================
;; PACKAGE MANAGEMENT
;; ============================================================================
(require 'package)
(add-to-list 'package-archives '("melpa-stable" . "https://stable.melpa.org/packages/"))
(package-initialize)

;; ============================================================================
;; BASIC EMACS BEHAVIOR
;; ============================================================================

;; Visual line mode (wrap long lines)
(global-visual-line-mode 1)

;; Hide menu bar for more screen real estate
(menu-bar-mode -1)

;; IDO mode for file/buffer completion
(ido-mode 1)
(ido-everywhere 1)

;; Backup files location
(setq backup-directory-alist '(("." . "~/zzzemacs-backups")))

;; ============================================================================
;; CUSTOM KEYBINDINGS
;; ============================================================================
(global-set-key (kbd "C-c t") 'org-sparse-tree)
(global-set-key (kbd "C-x C-d") 'deft)

;; ============================================================================
;; DEFT SETUP (for quick notes)
;; ============================================================================
(add-to-list 'load-path "~/.deft")
(require 'deft)

;; ============================================================================
;; ORGMODE CONFIGURATION
;; ============================================================================
(load-file "~/.emacs.d/lisp/orgmode.el")

;; ============================================================================
;; FACES (cosmetic customizations)
;; ============================================================================
(custom-set-variables
 '(package-selected-packages '(deft)))

(custom-set-faces)

(provide 'init)
