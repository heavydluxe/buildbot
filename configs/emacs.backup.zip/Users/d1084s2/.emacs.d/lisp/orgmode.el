;; ============================================================================
;; ORGMODE CONFIGURATION
;; ============================================================================
;; Reorganized 2026-08-01 for the domain-based @embrace_entropy layout.
;; No external packages required — all built-in org features.

;; ----------------------------------------------------------------------------
;; File paths
;; ----------------------------------------------------------------------------
(setq org-directory "~/sbemode/@embrace_entropy/")

;; Agenda scans EVERY .org file under the repo, at any depth, so the new
;; work/ home/ church/ ... folders are picked up automatically.
(setq org-agenda-files
      (directory-files-recursively "~/sbemode/@embrace_entropy/" "\\.org$"))

;; Archive now lives under archive/. Kept as .log so it stays OUT of the agenda.
(setq org-archive-location
      "~/sbemode/@embrace_entropy/archive/zzzorg-archive.log::")

;; Quick-capture inbox + refile anywhere in the agenda files.
(setq org-default-notes-file "~/sbemode/@embrace_entropy/inbox.org")
(setq org-refile-targets '((org-agenda-files :maxlevel . 3)))
(setq org-refile-use-outline-path 'file)
(setq org-outline-path-complete-in-steps nil)

;; Fold state/completion logs into a :LOGBOOK: drawer from now on (tidier).
(setq org-log-into-drawer t)

;; ----------------------------------------------------------------------------
;; TODO keywords + faces  (unchanged)
;; ----------------------------------------------------------------------------
(setq org-todo-keywords
      '((sequence "TODO(t)"
		  "InProc(i)"
		  "PROJECT(p)"
		  "Future(f)"
		  "Chat(c)"
		  "GOAL(g)"
		  "|"
		  "DONE(d)")))

(setq org-todo-keyword-faces
    '(("TODO" . (:foreground "brightwhite" :background "brightred"))
	("InProc" . (:foreground "black" :background "brightgreen"))
	("PROJECT" . (:foreground "black" :background "brightwhite"))
	("Future" . (:foreground "brightwhite" :background "brightblue"))
	("Chat" . (:foreground "black" :background "brightyellow"))
	("GOAL" . (:foreground "brightwhite" :background "darkorchid"))
    ("DONE" . (:foreground "brightblack" :background "black"))))

;; ----------------------------------------------------------------------------
;; Tags — all lowercase.  People are prefixed with @.
;; ----------------------------------------------------------------------------
(setq org-tag-alist
    '(("@me" . ?m)
	("@steve" . ?v)        ; boss
	("@scott" . ?s)
	("@becca" . ?b)
	("@courtney" . ?u)
	("@don" . ?d)
	("@matt" . ?a)
	("work" . ?w)
	("home" . ?h)
	("church" . ?c)
	("team" . ?t)          ; "bring to the team meeting"
	("learning" . ?l)))

;; ----------------------------------------------------------------------------
;; Agenda dispatcher + custom views
;;   C-c a          -> dispatcher
;;   a              -> normal day/week agenda (what `sb` opens)
;;   1 / 2 / 3      -> meeting surfaces (boss / team / learning)
;;   p then s/b/c/d/m -> per-person open items
;; ----------------------------------------------------------------------------
(global-set-key (kbd "C-c a") 'org-agenda)
(setq org-agenda-custom-commands
      '(("1" "Boss 1:1 (Steve)" tags-todo "@steve")
        ("2" "Team meeting"     tags-todo "team")
        ("3" "Learning"         tags-todo "learning")
        ("p" . "Per-person open items")
        ("ps" "Scott"    tags-todo "@scott")
        ("pb" "Becca"    tags-todo "@becca")
        ("pc" "Courtney" tags-todo "@courtney")
        ("pd" "Don"      tags-todo "@don")
        ("pm" "Matt"     tags-todo "@matt")))

;; ----------------------------------------------------------------------------
;; Capture  (C-c c)
;; ----------------------------------------------------------------------------
(global-set-key (kbd "C-c c") 'org-capture)
(setq org-capture-templates
      '(("t" "Todo -> inbox" entry
         (file+headline org-default-notes-file "Inbox")
         "* TODO %?\n  %U")
        ("n" "Note -> inbox" entry
         (file+headline org-default-notes-file "Inbox")
         "* %?\n  %U")
        ("m" "Meeting note" entry
         (file+datetree "~/sbemode/@embrace_entropy/work/notes/meetings.org")
         "* %? :work:\n  %U")))

;; ----------------------------------------------------------------------------
;; Deft — now searches the whole repo (notes live across many folders)
;; ----------------------------------------------------------------------------
(setq deft-extensions '("txt" "org" "md"))
(setq deft-directory "~/sbemode/@embrace_entropy")
(setq deft-recursive t)
(setq deft-default-extension "org")
(setq deft-new-file-format "%Y%b%d")

;; ----------------------------------------------------------------------------
;; On-demand log cleanup — "zero out" completion drawers  (C-c z)
;; ----------------------------------------------------------------------------
(defun bsd/clear-logbooks ()
  "Delete all :LOGBOOK: drawers in the current buffer.
Completion logs fold into :LOGBOOK: drawers; run this in recurring.org
whenever they pile up to wipe them in one keystroke.  Leaves :PROPERTIES:
drawers (and LAST_REPEAT) untouched, so recurrences keep working."
  (interactive)
  (let ((n 0))
    (save-excursion
      (goto-char (point-min))
      (while (re-search-forward
              "^[ \t]*:LOGBOOK:[ \t]*\n\\(?:.*\n\\)*?[ \t]*:END:[ \t]*\n?" nil t)
        (replace-match "")
        (setq n (1+ n))))
    (message "Cleared %d LOGBOOK drawer%s." n (if (= n 1) "" "s"))))

(global-set-key (kbd "C-c z") 'bsd/clear-logbooks)

(provide 'orgmode)
