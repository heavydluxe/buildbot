;; ============================================================================
;; ORGMODE CONFIGURATION
;; ============================================================================

;; Org file path settings
(setq org-archive-location "~/sbemode/@embrace_entropy/zzzorg-archive.log::")
(setq org-agenda-files (directory-files-recursively "~/sbemode/@embrace_entropy/" "\\.org$"))

;; Org-mode keyword settings
(setq org-todo-keywords
      '((sequence "TODO(t)"
		  "InProc(i)"
		  "PROJECT(p)"
		  "Future(f)"
		  "Chat(c)"
		  "GOAL(g)"
		  "|"
		  "DONE(d)")))

;; Org-mode keyword faces (colorful)
(setq org-todo-keyword-faces
    '(("TODO" . (:foreground "brightwhite" :background "brightred"))
	("InProc" . (:foreground "black" :background "brightgreen"))
	("PROJECT" . (:foreground "black" :background "brightwhite"))
	("Future" . (:foreground "brightwhite" :background "brightblue"))
	("Chat" . (:foreground "black" :background "brightyellow"))
	("GOAL" . (:foreground "brightwhite" :background "darkorchid"))
    ("DONE" . (:foreground "brightblack" :background "black"))))

;; Org-mode tag settings
(setq org-tag-alist
    '(("work" . ?w)
	("Steve" . ?s)
	("Team" . ?t)
	("home" . ?h)
	("church" . ?c)
	("Learning" . ?L)))

;; Org-mode custom agenda views by tag
(setq org-agenda-custom-commands
      '(("1" "Steve Meeting"
         tags-todo ":Steve:")
        ("2" "Team Meeting"
         tags-todo ":Team:")
	 ("3" "Learning Items"
	 tags-todo ":Learning")))

;; Deft notes configuration
(setq deft-extensions '("txt" "org" "md"))
(setq deft-directory "~/sbemode/@embrace_entropy/defts")
(setq deft-default-extension "org")
(setq deft-new-file-format "%Y%b%d")

(provide 'orgmode)
